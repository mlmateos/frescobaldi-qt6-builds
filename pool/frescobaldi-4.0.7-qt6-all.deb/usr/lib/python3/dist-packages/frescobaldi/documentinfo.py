# This file is part of the Frescobaldi project, http://www.frescobaldi.org/
#
# Copyright (c) 2008 - 2014 by Wilbert Berendsen
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
# See http://www.gnu.org/licenses/ for more information.

"""
Delivers information about a document.
"""


import itertools
import functools
import os
import re
import collections

from PyQt6.QtCore import (
    QCoreApplication, QObject, QSettings, QThread, QTimer, QUrl, pyqtSignal)

import document
import qsettings
import ly.lex
import lydocinfo
import lydocument
import app
import fileinfo
import cursortools
import tokeniter
import plugin
import variables
import lilypondinfo
import signals


__all__ = ['docinfo', 'info', 'mode']


def info(doc):
    """Returns a DocumentInfo instance for the given Document."""
    return DocumentInfo.instance(doc)


def docinfo(doc):
    """Return a LyDocInfo instance for the document."""
    return info(doc).lydocinfo()


def lilyinfo(doc):
    """Return a LilyPondInfo instance for the given document."""
    return info(doc).lilypondinfo()


def music(doc):
    """Return a music.Document instance for the document."""
    return info(doc).music()


def mode(doc, guess=True):
    """Returns the type of the given document. See DocumentInfo.mode()."""
    return info(doc).mode(guess)


def defaultfilename(doc):
    """Return a default filename that could be used for the document.

    The name is based on the score's title, composer etc.

    """
    i = info(doc)
    m = i.music()
    import ly.music.items as mus

    # which fields (in order) to harvest:
    s = QSettings()
    custom = s.value("custom_default_filename", False, bool)
    template = s.value("default_filename_template", "{composer}-{title}", str)
    if custom:
        # Retrieve all field names from the template string
        fields = [m.group(1) for m in re.finditer(r'\{(.*?)\}', template)]
    else:
        fields = ('composer', 'title')

    d = {}
    for h in m.find(mus.Header):
        for a in h.find(mus.Assignment):
            for f in fields:
                if f not in d and a.name() == f:
                    n = a.value()
                    if n:
                        t = n.plaintext()
                        if t:
                            d[f] = t
    # make filenames
    for k in d:
        d[k] = re.sub(r'\W+', '-', d[k]).strip('-')

    if custom:
        for k in fields:
            template = str.replace(template, '{' + k + '}', d.get(k, 'unknown'))
        filename = template
    else:
        filename = '-'.join(d[k] for k in fields if k in d)
    if not filename:
        filename = doc.documentName()
    ext = ly.lex.extensions[i.mode()]
    return filename + ext


class DocumentInfo(plugin.DocumentPlugin):
    """Computes and caches various information about a Document.

    To reduce lag, DocumentInfo computations are processed in the
    background while the document is being edited. As a consequence
    of this, DocumentInfo methods may return slightly older cached
    data while edits are being processed. This usually does not
    cause problems in practice, but if you do need absolutely
    current data, you can connect to your instance's contentsChanged
    signal to be notified when this processing has finished.

    """
    def __init__(self, doc):
        self._workerActive = False
        self._documentChanged = False
        # _lydocinfo and _music will be populated the first time their
        # respective getter functions are called
        self._reset()
        if isinstance(doc, document.EditorDocument):
            doc.contentsChanged.connect(self._invalidate)
            doc.changesStopped.connect(self._processChanges)
            doc.closed.connect(self._reset)

    contentsChanged = signals.Signal()

    def _reset(self):
        """Clear cached data when the document is opened or closed."""
        self._waitForWorker()
        self._lydocinfo = None
        self._music = None

    def lydocinfo(self):
        """Return the lydocinfo instance for our document."""
        self._waitForWorker()
        if self._lydocinfo is None:
            self._lydocinfo = _Worker.lydocinfo(self.document())
        return self._lydocinfo

    def music(self):
        """Return the music.Document instance for our document."""
        self._waitForWorker()
        if self._music is None:
            self._music = _Worker.music(self.document())
        self._music.include_path = self.includepath()
        return self._music

    def mode(self, guess=True):
        """Returns the type of document ('lilypond, 'html', etc.).

        The mode can be set using the "mode" document variable.
        If guess is True (default), the mode is auto-recognized based on the contents
        if not set explicitly using the "mode" variable. In this case, this function
        always returns an existing mode.

        If guess is False, auto-recognizing is not done and the function returns None
        if the mode wasn't set explicitly.

        """
        mode = variables.get(self.document(), "mode")
        if mode in ly.lex.modes:
            return mode
        if guess:
            return self.lydocinfo().mode()

    def includepath(self):
        """Return the configured include path.

        A path is a list of directories.

        If there is a session specific include path, it is used.
        Otherwise the path is taken from the LilyPond preferences.

        Currently the document does not matter.

        """
        # get the global include path
        include_path = qsettings.get_string_list(
            QSettings(), "lilypond_settings/include_path")

        # get the session specific include path
        import sessions
        session_settings = sessions.currentSessionGroup()
        if session_settings and session_settings.value("set-paths", False, bool):
            sess_path = qsettings.get_string_list(session_settings, "include-path")
            if session_settings.value("repl-paths", False, bool):
                include_path = sess_path
            else:
                include_path = sess_path + include_path

        return include_path

    def jobinfo(self, create=False):
        """Returns a two-tuple(filename, includepath).

        The filename is the file LilyPond shall be run on. This can be the
        original filename of the document (if it has a filename and is not
        modified), but also the filename of a temporarily saved copy of the
        document.

        The includepath is the same as self.includepath(), but with the
        directory of the original file prepended, only if a temporary
        'scratchdir'-area is used and the document does include other files
        (and therefore the original folder should be given in the include
        path to LilyPond).

        """
        includepath = self.includepath()
        filename = self.document().url().toLocalFile()

        # Determine the filename to run the engraving job on
        if not filename or self.document().isModified():
            # We need to use a scratchdir to save our contents to
            import scratchdir
            scratch = scratchdir.scratchdir(self.document())
            if create:
                scratch.saveDocument()
            if filename:
                includepath.insert(0, os.path.dirname(filename))
            if create or (scratch.path() and os.path.exists(scratch.path())):
                filename = scratch.path()
        return filename, includepath

    def includefiles(self):
        """Returns a set of filenames that are included by this document.

        The document's own filename is not added to the set.
        The configured include path is used to find files.
        Included files are checked recursively, relative to our file,
        relative to the including file, and if that still yields no file, relative
        to the directories in the includepath().

        This method uses caching for both the document contents and the other files.

        """
        return fileinfo.includefiles(self.lydocinfo(), self.includepath())

    def lilypondinfo(self):
        """Returns a LilyPondInfo instance that should be used by default to engrave the document."""
        version = self.lydocinfo().version()
        if version and QSettings().value("lilypond_settings/autoversion", False, bool):
            return lilypondinfo.suitable(version)
        return lilypondinfo.preferred()


    def child_urls(self):
        """Return a tuple of urls included by the Document.

        This only returns urls that are referenced directly, not searching
        via an include path. If the Document has no url set, an empty tuple
        is returned.

        """
        url = self.document().url()
        if url.isEmpty():
            return ()
        return tuple(url.resolved(QUrl(arg)) for arg in self.lydocinfo().include_args())

    def basenames(self):
        """Returns a list of basenames that our document is expected to create.

        The list is created based on include files and the define output-suffix and
        \bookOutputName and \bookOutputSuffix commands.
        You should add '.ext' and/or '-[0-9]+.ext' to find created files.

        """
        # if the file defines an 'output' variable, it is used instead
        output = variables.get(self.document(), 'output')
        filename = self.jobinfo()[0]
        if output:
            dirname = os.path.dirname(filename)
            return [os.path.join(dirname, name.strip())
                    for name in output.split(',')]

        mode = self.mode()

        if mode == "lilypond":
            return fileinfo.basenames(self.lydocinfo(), self.includefiles(), filename)

        elif mode == "html":
            pass

        elif mode == "texinfo":
            pass

        elif mode == "latex":
            pass

        elif mode == "docbook":
            pass

        return []

    def _invalidate(self):
        """Invalidate the cache when the document is changed.

        This forces the worker to regenerate cached data the next time
        _processChanges is called. The old data remains in the cache
        until the worker finishes, so DocumentInfo will return slightly
        outdated information while the worker is running. (This is the
        dirty secret to how we avoid lag.)

        """
        self._documentChanged = True

    def _processChanges(self):
        """Update cached data when the document is changed.

        This triggers a worker to regenerate _lydocinfo and _music
        in a background thread. These are slow operations, and
        processing them in the main thread caused significant lag
        when editing large LilyPond documents in older Frescobaldi
        versions (see issue #473).

        """
        # Note the worker operates on the live Document instance,
        # so it always sees the latest changes even if they happen
        # while the worker is running. There is no need to ever
        # retrigger an active worker; doing so will only cause more
        # of the very lag this design was intended to reduce.
        if self._documentChanged and not self._workerActive:
            try:
                worker = self._worker_instance
            except AttributeError:
                worker = self._worker_instance = _Worker(self.document())
                worker.moveToThread(_Worker.preferredThread())
                worker.finished.connect(self._slotWorkerFinished)

            self._workerActive = True
            # the worker modifies the document so we can't use a clone()
            self.document().moveToThread(worker.thread())
            QTimer.singleShot(0, worker.work)

    def _slotWorkerFinished(self, data):
        self._lydocinfo = data.lydocinfo
        self._music = data.music
        self._workerActive = False
        self._documentChanged = False
        self.contentsChanged.emit()

    def _waitForWorker(self):
        """Block (but keep the UI running) while the worker is active."""
        while self._workerActive:
            QCoreApplication.processEvents()


# named tuple type to pass data from the worker to the main thread
_WorkerData = collections.namedtuple("_WorkerData", "lydocinfo music")


class _Worker(QObject):
    """Worker to perform slow update operations in a separate thread."""
    def __init__(self, document):
        super().__init__()
        self._document = document
        self._documentThread = document.thread()

    def work(self):
        """Trigger this using a signal or QTimer to perform work."""
        lydocinfoData = self.lydocinfo(self._document)
        musicData = self.music(self._document)
        # return the document to its original thread
        self._document.moveToThread(self._documentThread)
        self.finished.emit(_WorkerData(lydocinfoData, musicData))

    @classmethod
    def preferredThread(cls):
        """Return the QThread where we want workers to live."""
        # all workers can share the same thread since we only have one
        # active document, and therefore one active worker, at a time
        try:
            thread = cls._thread
        except AttributeError:
            thread = cls._thread = QThread()
            thread.finished.connect(thread.deleteLater)
            thread.start()
        return thread

    # these are static methods so we can also call them directly from the
    # main thread as needed

    @staticmethod
    def lydocinfo(document):
        """Returns the data for DocumentInfo.lydocinfo()."""
        doc = lydocument.Document(document)
        v = variables.manager(document).variables()
        return lydocinfo.DocInfo(doc, v)

    @staticmethod
    def music(document):
        """Returns the data for DocumentInfo.music()."""
        import music
        doc = lydocument.Document(document)
        return music.Document(doc)

    finished = pyqtSignal("PyQt_PyObject")  # WorkerData
